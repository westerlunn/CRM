﻿using System.Security.Cryptography.X509Certificates;

namespace CRM
{
    class Program
    {
        static void Main(string[] args)
        {
            //GetDatabase.GetCustomers();
            UserInterface.Menu();
            //GetDatabase.UpdateCustomer(5, "Anton", "Oq", "anoq@gmail.com", "0708909876");
            //GetDatabase.RemoveCustomerFromDatabase(6);
            //GetDatabase.AddCustomerToDatabase("Karl", "Blå", "hejhopp@plupp.se", "0709876543");
            //GetDatabase.GetInfoFromDatabase();
        }
    }
}
